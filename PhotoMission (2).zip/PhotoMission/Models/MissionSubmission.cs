﻿using System;

namespace PhotoMission.Models
{
    public class MissionSubmission
    {
        public int Id { get; set; } // Primary key
        public int MissionId { get; set; } // Foreign key to Mission
        public Mission Mission { get; set; } // Navigation property to Mission
        public string Description { get; set; } // Description for the submission
        public string PhotoPath { get; set; } // Path to the uploaded photo
        public DateTime SubmissionDate { get; set; } // Date the submission was made
        public bool IsValid { get; set; } // Validation status
    }
}
