﻿using Microsoft.EntityFrameworkCore;
using PhotoMission.Models;

namespace PhotoMission.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Mission> Missions { get; set; }
        public DbSet<MissionSubmission> MissionSubmissions { get; set; }
    }
}
