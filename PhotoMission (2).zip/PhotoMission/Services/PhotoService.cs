﻿using Microsoft.AspNetCore.Mvc;

namespace PhotoMission.Services
{
    public class PhotoService : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
