﻿using PhotoMission.Data;
using PhotoMission.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace PhotoMission.Services
{
    public class MissionService : IMissionService
    {
        private readonly ApplicationDbContext _context;

        public MissionService(ApplicationDbContext context)
        {
            _context = context;
        }

        // Method to save a mission submission
        public async Task SaveSubmissionAsync(MissionSubmission submission)
        {
            _context.MissionSubmissions.Add(submission);
            await _context.SaveChangesAsync();
        }

        // Method to get a mission by its ID
        public async Task<Mission> GetMissionByIdAsync(int missionId)
        {
            return await _context.Missions
                                 .FirstOrDefaultAsync(m => m.Id == missionId);
        }
    }
}
